package com.training.pages;

import com.google.inject.Key;
import com.training.constants.ApplicationConstants;
import net.bytebuddy.asm.Advice;
import org.aeonbits.owner.Config;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class CasesPage extends BasePage {
    private static final Logger logger = LoggerFactory.getLogger(CasesPage.class);
    // private static final By btncreateNewCase = By.xpath("//button[text()='Create']");
    private static By createBtn = By.xpath("//button[@class='ui linkedin button' and text()='Create']");
    private static By buttonSave = By.xpath("//button[@class='ui linkedin button']/i[@class='save icon']");
    private static final By titleXp = By.xpath("//input[@name='title']");
    private static final By txtCompany = By.xpath("//div[@name='company']/input");
    private static final By txtContacts = By.xpath("//div[@name='contact']/input");
    private static final By txtDeals = By.xpath("//div[@name='deal']/input");
    private static final By savePage = By.xpath("//span[@class='selectable ']");
    private  static final By contactXpath = By.xpath("//label[text()='Contact']/parent::div[@class='ui field']/div");
    private static final By companyXPath = By.xpath("//label[text()='Company']/parent::div[@class='ui field']/div");
    //private static final By checkBoxPath = By.xpath("//table/tbody/tr/td[1]");
    String checkBoxPath = "//table/tbody/tr/td[1]";
    private static final By deleteLoc = By.xpath("//div[@class='ui page modals dimmer transition visible active']//button[text()='Delete']");
    //String s = RandomStringUtils.randomAlphanumeric(7);

    // private static final By sSearchNSelectDropDownExisting =By.xpath("//div[contains(@class,'ui active visible fluid')]//div[@role='option']//span]");
    //private static final By btnSave = By.xpath("//button[text()='Save']");


    public CasesPage(WebDriver driver) {
        super(driver);
    }
    public CasesPage createCase(HashMap<String,String> objCasesData) throws InterruptedException {
        clickOnNewCasesButton();
        enterCaseDetails(objCasesData);
        clickOnSaveButton();
        checkPageHeader(objCasesData.get("casename"),"page is not saved");
        return this;
    }

    public CasesPage clickOnSaveButton() {
        scriptAction.waitUntilElementIsVisible(buttonSave,ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(buttonSave);
        logger.info("case page is successfully saved!");
        return this;
    }

    public CasesPage clickOnNewCasesButton() {
        scriptAction.waitUntilElementIsVisible(createBtn, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(createBtn);
        checkPageHeader("Create new Case", "New Case page is not displayed");
        return this;
    }

    public CasesPage enterCaseDetails(HashMap<String,String> mapCases) throws InterruptedException {
        scriptAction.waitUntilElementIsVisible(titleXp,ApplicationConstants.MEDIUM_TIMEOUT);
        if(mapCases.containsKey("title")) {
            scriptAction.clearAndInputText(titleXp,mapCases.get("title"));
        }
        String user = "";
         if(mapCases.containsKey("user")) {
            user = mapCases.get("user");
        }
        if(mapCases.containsKey("names")) {
            setPrivate(user, new String[]{mapCases.get("names")});
        }
        if(mapCases.containsKey("assignTo")) {
            selectItemFromDropdown("Assigned To",mapCases.get("assignTo"));
        }
        if(mapCases.containsKey("contact")) {
            searchNSelectItemFromList("Contact",mapCases.get("contact"));
        }
        if(mapCases.containsKey("company")) {
            searchNSelectItemFromList("Company",mapCases.get("company"));
        }
        return this;
    }

   /* public CasesPage enterCaseDetails(String title,String byUsing,String[] names,String assignTo,String contact,String company ) {
        scriptAction.waitUntilElementIsVisible(titleXp,ApplicationConstants.MEDIUM_TIMEOUT);
        if (title.length() > 0) {
            scriptAction.inputText(titleXp, title);
        }
        if (byUsing.length() > 0) {
            setPrivate(byUsing,names);
        }
        if(assignTo.length() > 0){
            selectItemFromDropdown("Assigned To",assignTo);
        }
        if(contact.length()>0) {
            searchNSelectItemFromList("Contact",contact);
        }
        if(company.length()>0) {
            searchNSelectItemFromList("Company", company);
        }

        return this;
    }*/
    public void editCase(HashMap<String,String> mapCasesEdit) throws InterruptedException {
        performTableOperation(mapCasesEdit.get("existingcase"),"edit");
        enterCaseDetails(mapCasesEdit);
        clickOnSaveButton();
        logger.info("Edited successfully");
    }
    public void deleteCase(String searchName,String sOperation) {
        performTableOperation(searchName,"delete");
        checkPopupIsDisplayed("Confirm Deletion");
        if(sOperation.equals("CANCEL")) {
            performOperationOnPopUp(sOperation);
            logger.info("Delete is cancelled");
        }else if(sOperation.equals("DELETE")) {
            performOperationOnPopUp(sOperation);
            logger.info("Delete is successful");
        }
    }


//    public void searchFilters(String name) {
//        selectEntity("Cases");
//        filter(searchEntity,operatorEntity,name);
//
//    }

    /*public void saveCases(String caseTitle) {
        //scriptAction.waitUntilElementIsVisible(savePage,ApplicationConstants.MEDIUM_TIMEOUT);
        checkPageHeader(caseTitle,"case is not saved");
    }*/
}
