package com.training.testcases.Deals;

import com.training.pages.BasePage;
import com.training.pages.DealsPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class DealsAllFieldsValidation extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(DealsAllFieldsValidation.class);
   // boolean bDelete = false;
    @Test(description = "Create Deals with All fields")
    public void DealsAllField() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Deals");
        ExtentTestManager.getTest().pass("Selected Deals Page");

        HashMap<String, String> objDealsTestData = new HashMap<String, String>();
        DealsPage dealsPage = new DealsPage(getDriver());
        String dealsTitle = CommonUtil.getRandomString("Deals",10);
        objDealsTestData.put("title",dealsTitle);
        objDealsTestData.put("contacts","Tcs");
        objDealsTestData.put("stage","Qualify");
        dealsPage.createDeal(objDealsTestData);
        logger.info("deal is created");
        Thread.sleep(3000);
        dealsPage.selectEntity("Deals");
        dealsPage.deleteEntity(dealsTitle,"DELETE");
        Thread.sleep(1000);
        dealsPage.verifyRecordNotDisplayed(dealsTitle);


        // bDelete = true;
       // Thread.sleep(2000);
        /*dealsPage.selectEntity("Deals");
        dealsPage.deleteEntity(dealsTitle,"DELETE");*/
    }
   /* @AfterMethod
    public void postCondition() throws Exception {
        if(!bDelete) return;
        DealsPage dealsPage = new DealsPage(getDriver());
        Thread.sleep(2000);
        dealsPage.selectEntity("Deals");
        dealsPage.deleteEntity(dealsTitle,"DELETE");

    }*/
}
