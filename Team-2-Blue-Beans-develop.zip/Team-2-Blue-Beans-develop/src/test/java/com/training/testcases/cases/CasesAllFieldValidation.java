package com.training.testcases.cases;

import com.training.pages.*;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import com.training.utils.ConfigurationDetailsUtil;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static com.training.support.BrowserFactory.getDriver;

    public class CasesAllFieldValidation extends BaseTest{
        private static final Logger logger = LoggerFactory.getLogger(CasesAllFieldValidation.class);

        @Test(description = "Create cases with All fields")
        public void caseAllField() throws Exception {

            LoginPage loginPage = new LoginPage(getDriver());
            loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
            ExtentTestManager.getTest().pass("Logged in to application");
            loginPage.selectEntity("Cases");
            ExtentTestManager.getTest().pass("Selected Cases Page");

            CasesPage casesPage = new CasesPage(getDriver());
            HashMap<String,String> objCasesData = new HashMap<>();
            String casesTitle = "pavani".concat(CommonUtil.getCurrentTime());
            objCasesData.put("title",casesTitle);
            objCasesData.put("user","withusers");
            objCasesData.put("names","pavani kopanathi");
            objCasesData.put("assignTo","Hajeera  Begum");
            objCasesData.put("contact","hasan");
            objCasesData.put("company","Tcs");
            casesPage.createCase(objCasesData);
            logger.info("case is created",casesTitle);

            casesPage.selectEntity("Cases");
            casesPage.deleteCase(casesTitle,"DELETE");
            casesPage.verifyRecordNotDisplayed(casesTitle);

        }
    }


