package com.training.pages;

//import com.sun.javafx.binding.StringFormatter;

import com.training.constants.ApplicationConstants;
import com.training.utils.WebUtil;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//this class should have only common web related option
public class BasePage {
    private static Logger logger = LoggerFactory.getLogger(BasePage.class);

    protected final WebUtil scriptAction;
    protected final WebDriver driver;
    //Left Pane
    private final String lnkLeftPaneEntityName = "//a[@href='/%s']";
    private final String lblPageHeader = "//div[contains(@class,'ui header')]//span[text()='%s']";
    private final String pageDropDown = "//label[text()='%s']/.././div[@role='listbox']";
    private final String selectValueDropDown = "//div[@class='visible menu transition']/div/span[text()='%s']";
    //private final static By deleteIcon = By.xpath("//button[@class='ui basic button item']//parent::div/button[2]");
    private final String rubbishBinPage = "//div[@class='ui menu']/a[text()='%s']";
    private final String rubbishBinCBox = "//td/a[text()='%s']/ancestor::tr//td[@class='collapsing']";
    //private final static By okButton = By.xpath("//button[@class='ui primary button']");

    By errorMessage = By.xpath("//span[@class='inline-error-msg']");
    By settingIcon = By.xpath("//div[@class='ui basic button floating item dropdown']");
    String settingItemTxt = "//span[@class='text' and text()='%s']";
    //    private String navigatedEntityPageName = "//div[@id='mainContent']//div[contains(@id,'ViewSelector') and contains(@aria-label,'%s')]";
    //    private String navigatedEntityPageName = "//div[@id='mainContent']//div[contains(@id,'ViewSelector') and contains(@aria-label,'%s')]";
//    private String navigatedPageName = "//div[@id='mainContent']//h1[@title='%s' and @data-id='header_title']";
    private static final By popUp = By.xpath("//div[@class='ui page modals dimmer transition visible active']");
    String privateAccess = "//label[text()='Access']/following::div/div[2]/div[@class='ui fluid multiple selection dropdown']";
    String publicLoc = "(//label[text()='Access']/following::div/div/button[contains(@class,positive)])[1]";
    String accessDropDown = "//div[@class='visible menu transition']/div/span[contains(text(),'%s')]";
    private String popUpHeader = "//div[@class='ui page modals dimmer transition visible active']//div[@class='header' and text()='%s']";
    //error messages at boundary
    private String lengthErrorMsg = "//div[@class='ui error floating icon message']";
    private static By popUpHeader1 = By.xpath("//div[@class='ui modal transition visible active']");       ///div[@class='ui page modals dimmer transition visible active']
    //setfilter

    String showFilterButton = "//button[@class = 'ui linkedin button' and text() = 'Show Filters']";
    String searchDrpDwn = "//div[@class='ui search selection dropdown']";
    String searchEntity = "//div[@role='combobox']//div//div//span[text() ='%s']";
    String operatorDrpDwn = "//div[@name='operator']";
    String operatorEntity = "//div[@name='operator']//div//div//span[text() = '%s']";
    String searchValue = "//input[@name = 'value']";
    String searchButton = "//i[@class= 'search small icon']";
    private String lengthErrorMsz = "//div[@class='ui error floating icon message']";
    private String comboBoxXpath = "//label[text()='%s'] //parent:: div //div[@role='combobox']//input";
    private final String viewXPath = "//a[text()='%s']/ancestor::td/following-sibling::td[@class='right aligned collapsing options-buttons-container']/a/button[@class='ui icon button']/i[@class='unhide icon']";
    private final String editXPath = "//a[text()='%s']/ancestor::td/following-sibling::td[@class='right aligned collapsing options-buttons-container']/a/button/i[@class='edit icon']";
    private final String deleteXPath = "//a[text()='%s']/ancestor::td/following-sibling::td[@class='right aligned collapsing options-buttons-container']/button/i[@class='trash icon']";
    // By checkMarkIcon = By.xpath("//i[@class='checkmark icon']");

    //private final String viewXPath = "//a[text()='%s']/parent::td/following-sibling::td[@class='right aligned collapsing options-buttons-container']//a[1]";
    //private final String editXPath = "//a[text()='%s']/parent::td/following-sibling::td[@class='right aligned collapsing options-buttons-container']//a[2]";
    //private final String deleteXPath = "//a[text()='xwcYFU']/parent::td/following-sibling::td[@class='right aligned collapsing options-buttons-container']//div/button";
    // By checkMarkIcon = By.xpath("//i[@class='checkmark icon']");
    private static final By locListBox = By.xpath("//div[contains(@class,'ui active visible fluid')]//div[@role='option']");
    private final String locExistItem = "//div[contains(@class,'ui active visible fluid')]//div[@role='option']//span[contains(text(),'%s')]";
    private final String locNewItem = "//div[contains(@class,'ui active visible fluid')]//div[@role='option']//span/b[contains(text(),'%s')]";
    By dlgLocDelete = By.xpath("//div[@class='ui modal transition visible active']");
    String tdLocator = "//a[text()='%s']";
    private final String recordVerify = "//a[text()='%s']";
    private static By popUpPage = By.xpath("//div[@class='ui page modals dimmer transition visible active']");
    //By checkMarkIcon = By.xpath("//i[@class='checkmark icon']");
    //By confirmPopUpTxt = By.xpath("//div[@class='header' and text()='Confirm']");
    //By checkMarkIcon = By.xpath("//i[@class='checkmark icon']");
    // By confirmPopUpTxt = By.xpath("//div[@class='header' and text()='Confirm']");
    private static final By btnOkInPopup = By.xpath("//div[@class='ui page modals dimmer transition visible active']//button[text()='%s']");
    private static final By btnCancelInPopup = By.xpath(" //div[@class='ui page modals dimmer transition visible active']//button[text()='Cancel']");
    private static final By btnDeleteInPopup = By.xpath("//div[@class='ui page modals dimmer transition visible active']//button[text()='Delete']");
    private static By purgeButton = By.xpath("//button[@class='ui negative button']");
    private static By restoreButton = By.xpath("//i[@class='undo icon']");
    private static final String popUpLoc = "//div[@class='actions']//button[text()='%s']";
    private static final String buttonOnPopup = "//div[@class='ui page modals dimmer transition visible active']//button[text()='%s']";
    private static By deIcon = By.xpath("//button[@class='ui basic button item']//parent::div/button[2]");

    //private  final String  recordVerify = "//th[text()='Name']//ancestor::table//tbody//td/a[text()='%s']";
    //private String comboBoxXpath = "//label[text()='%s']/parent::div//div[@role='combobox']";

    //    private final String pageDropDown = "//label[text()='%s']/.././div[@role='listbox']";
//    private final String selectValueDropDown = "//div[@class='visible menu transition']/div/span[text()='%s']";
    public enum EntityPanel {
        Calendar,
        Contacts,
        Companies,
        Deals,
        Tasks,
        Cases,
        Products,
        Calls
    }

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.scriptAction = new WebUtil(driver);
    }

    public String takePageScreenShot() {
        return this.scriptAction.takeScreenshotAndSave();
    }

    public void selectEntity(String sEntityName) {
        //click on left panel entity
        scriptAction.clickElement(By.xpath(String.format(lnkLeftPaneEntityName, sEntityName.toLowerCase())));
        logger.info(sEntityName, "clicked on panel");
        //wait until page header is visible
        scriptAction.waitUntilElementIsVisible(By.xpath(String.format(lblPageHeader, sEntityName)), ApplicationConstants.MEDIUM_TIMEOUT);
        //check the page
        checkPageHeader(sEntityName, "msg: " + sEntityName + "page is not displayed");
    }

    //Checking the page header
    public void checkPageHeader(String sValue, String errMessage) {
        By locTxtDropDown = By.xpath(String.format(lblPageHeader, sValue));
        scriptAction.waitUntilElementIsVisible(locTxtDropDown, ApplicationConstants.MEDIUM_TIMEOUT, errMessage);
    }

    // Check Field Require Error Message
    public void errMessage(String sExpectedErrorMessage) {
        String sActualErrorMessage = getFieldErrorMessages();
        //wait the until error message is display
        scriptAction.waitUntilElementIsVisible(errorMessage, ApplicationConstants.MEDIUM_TIMEOUT);
        // Assert compare error messages
        //Assert.assertEquals(sExpectedErrorMessage,sActualErrorMessage);
        Assert.assertTrue(sExpectedErrorMessage.contains(sActualErrorMessage), "error message is not matched");
    }

    private String getFieldErrorMessages() {
        String sAllErrorMessage = "";
        List<WebElement> listOfElements = scriptAction.findElements(errorMessage);
        //Loop all the error message
        for (WebElement element : listOfElements) {
            String sCurrentMessage;
            sCurrentMessage = element.getText();
            sAllErrorMessage = sAllErrorMessage.concat(sCurrentMessage).concat(",");
        }
        //Remove last character
        if (sAllErrorMessage.length() > 0) {
            sAllErrorMessage = sAllErrorMessage.substring(0, sAllErrorMessage.length() - 1);
        }
        return sAllErrorMessage;
    }

    public void rubbishBin(String operation) {
        //wait until element is display of trash icon
        scriptAction.waitUntilElementIsClickable(deIcon, ApplicationConstants.SHORT_TIMEOUT);
        //click on trash icon
        scriptAction.clickElement(deIcon);
        String updatedRubbishBinPage = String.format(rubbishBinPage, operation);
        scriptAction.waitUntilElementIsVisible(By.xpath(updatedRubbishBinPage), ApplicationConstants.MEDIUM_TIMEOUT);
        //click on page in rubbish bin page
        scriptAction.clickElement(By.xpath(updatedRubbishBinPage));
    }

    public void purge(String sCheckBox) {
        String upDatedCheckBox = String.format(rubbishBinCBox, sCheckBox);
        scriptAction.waitUntilElementIsVisible(By.xpath(upDatedCheckBox), ApplicationConstants.MEDIUM_TIMEOUT);
        //click on check box
        scriptAction.clickElement(By.xpath(upDatedCheckBox));
    }

    public void purgeSelected(String operation, String sPopUp) {
        // scriptAction.waitUntilElementIsVisible(purgeButton, ApplicationConstants.MEDIUM_TIMEOUT);
        if (operation.equals("Purge")) {
            // click on PurgeSelected
            scriptAction.waitTillClickableAndClick(purgeButton, ApplicationConstants.MEDIUM_TIMEOUT);
            performOperationOnPopUp(sPopUp);
        }
        //click on Restore
        else if (operation.equals("Restore")) {
            scriptAction.waitTillClickableAndClick(restoreButton, ApplicationConstants.MEDIUM_TIMEOUT);
            performOperationOnPopUp(sPopUp);
        }
    }

    public boolean searchNSelectItemFromList(String searchLocator, String value) {
        String updatedLocator = String.format(comboBoxXpath, searchLocator);
        scriptAction.waitUntilElementIsVisible(By.xpath(updatedLocator), ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(By.xpath(updatedLocator));
        scriptAction.mouseOver(By.xpath(updatedLocator), value);
        scriptAction.waitUntilElementIsVisible(locListBox, ApplicationConstants.MEDIUM_TIMEOUT);
        boolean Exists = scriptAction.isElementPresent(By.xpath(String.format(locExistItem, value)));
        //verify the combo box list is exists or not
        if (Exists) {
            //click on exist item in list
            scriptAction.clickElement(By.xpath(String.format(locExistItem, value)));
        } else {
            boolean NewExists = scriptAction.isElementPresent(By.xpath(String.format(locNewItem, value)));
            if (!NewExists) {
                logger.error("Item is not displayed");
                return false;
            }
            //click on new item in list
            scriptAction.clickElement(By.xpath(String.format(locNewItem, value)));
        }
        return true;
    }

    public void errorMessages(String expErrorMsg) {
        scriptAction.waitUntilElementIsVisible(By.xpath(lengthErrorMsz), ApplicationConstants.SHORT_TIMEOUT);
        String actual = scriptAction.getText(By.xpath(lengthErrorMsz));
        Assert.assertEquals(actual, expErrorMsg);
    }

    public void selectItemFromDropdown(String sDropdownItem, String sSearchValue) {
        By locTxtDropDown = By.xpath(String.format(pageDropDown, sDropdownItem));
        scriptAction.waitUntilElementIsVisible(locTxtDropDown, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.scrollToElement(locTxtDropDown);
        //click the element of particular drop down
        scriptAction.clickElement(locTxtDropDown);
        //wait until element is display in drop down
        scriptAction.waitUntilElementIsVisible(By.xpath(String.format(selectValueDropDown, sSearchValue)), ApplicationConstants.MEDIUM_TIMEOUT);
        //click on element in select value in drop down
        scriptAction.clickElement(By.xpath(String.format(selectValueDropDown, sSearchValue)));
    }

    public void scroll() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,400)");
    }

    public void refreshPage() {
        scriptAction.refreshPage();
    }

    //Usage selectToggleButton("Closed","ON") or selectToggleButton("Do not Text","OFF")
    public boolean selectToggleButton(String sToggleLabel, String sOperation) {
        //sOperation = "ON","OFF"
        return true;
    }


    public void performTableOperation(String sSearchValue, String operation) {
        //find the Search value is displayed in the table
        By eleTable = By.xpath(String.format(tdLocator, sSearchValue));
        scriptAction.waitUntilElementIsVisible(eleTable, ApplicationConstants.MEDIUM_TIMEOUT, "Value is not display in table operation");
        switch (operation) {
            case "view": {
                scriptAction.clickElement(By.xpath(String.format(viewXPath, sSearchValue)));
                //Check page header
                //checkPageHeader(sSearchValue, "view page is not displayed");
                break;
            }
            case "edit": {
                scriptAction.clickElement(By.xpath(String.format(editXPath, sSearchValue)));
                // Check Page header
                //checkPageHeader(sSearchValue, "Edit page is not displayed");
                break;
            }
            case "delete": {
                scriptAction.clickElement(By.xpath(String.format(deleteXPath, sSearchValue)));
                //wait until popUp is displayed
                scriptAction.waitUntilElementIsVisible(dlgLocDelete, ApplicationConstants.SHORT_TIMEOUT, "Delete icon is not displayed");
            }
        }
    }

    public void checkPopupIsDisplayed(String sHeaderName) {
        //wait until pop up is displayed
        scriptAction.waitUntilElementIsVisible(popUpPage, ApplicationConstants.MEDIUM_TIMEOUT, "PopUp page is not displayed");
        By updatePopUpLoc = By.xpath(String.format(popUpHeader, sHeaderName));
        scriptAction.waitUntilElementIsVisible(updatePopUpLoc, ApplicationConstants.MEDIUM_TIMEOUT, "popUp header is not displayed");
    }


    public void setPrivate(String users, String[] names) {
        WebElement publicAccess = scriptAction.findElement(By.xpath(publicLoc));
        scriptAction.clickElement(By.xpath(publicLoc));
        Assert.assertTrue(publicAccess.isDisplayed(), "user in private access");
        if (users.equals("withusers")) {
            scriptAction.clickElement(By.xpath(privateAccess));
            List<String> entity = new ArrayList<>(Arrays.asList(names));
            for (String sEntity : entity) {
                String updatedLoc = String.format(accessDropDown, sEntity);
                scriptAction.waitUntilElementIsVisible(By.xpath(updatedLoc), ApplicationConstants.SHORT_TIMEOUT);
                scriptAction.clickElement(By.xpath(updatedLoc));
            }
        }
    }

    //Perform action on popup
    public void performOperationOnPopUp(String sOperation) {
        scriptAction.waitUntilElementIsVisible(popUpHeader1, ApplicationConstants.MEDIUM_TIMEOUT);
        String sButton = "";
        switch (sOperation.toUpperCase()) {
            case "OK":
                sButton = "OK";
                break;
            case "CANCEL":
                sButton = "Cancel";
                break;
            case "DELETE":
                sButton = "Delete";
                break;
        }
        By popUpButtonLoc = By.xpath(String.format(buttonOnPopup, sButton));
        scriptAction.waitUntilElementIsVisible(popUpButtonLoc, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(popUpButtonLoc);
    }

    //To Display record or not
    public void verifyRecordDisplayed(String sSearchRecord) throws Exception {
        recordVerification(sSearchRecord, true);
    }

    public void verifyRecordNotDisplayed(String sSearchRecord) throws Exception {
        recordVerification(sSearchRecord, false);
    }

    public boolean recordVerification(String value, boolean expectedConditions) throws Exception {
        String record = String.format(recordVerify, value);
        boolean d = scriptAction.isElementVisible(By.xpath(record), ApplicationConstants.MEDIUM_TIMEOUT);
        if (d == expectedConditions) {
            System.out.println("Verification passed");
        } else {
            throw new Exception("Verification failed");
        }
        return true;
    }


    public void logout(String sItem) {
        //wait until element setting is Click
        scriptAction.waitTillClickableAndClick(settingIcon, ApplicationConstants.SHORT_TIMEOUT);
        By logoutLoc = By.xpath(String.format(settingItemTxt, sItem));
        //click on logout button
        scriptAction.clickElement(logoutLoc);
    }

    public void filter(String fieldName, String operator, String value) {
        //clicking on show filter
        scriptAction.waitUntilElementIsVisible(By.xpath(showFilterButton), ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(By.xpath(showFilterButton));
        //clicking on search combo-box
        scriptAction.waitUntilElementIsVisible(By.xpath(searchDrpDwn), ApplicationConstants.SHORT_TIMEOUT);
        scriptAction.clickElement(By.xpath(searchDrpDwn));
        //select value from the search combo-box
        scriptAction.clickElement(By.xpath(String.format(searchEntity, fieldName)));
        //clicking on operator combo-box
        scriptAction.waitUntilElementIsVisible(By.xpath(operatorDrpDwn), ApplicationConstants.SHORT_TIMEOUT);
        scriptAction.clickElement(By.xpath(operatorDrpDwn));
        //select value from the operator combo-box
        scriptAction.clickElement(By.xpath(String.format(operatorEntity, operator)));
        //enter a input text in value textbox
        scriptAction.inputText(By.xpath(searchValue), value);
        //clicking on search button
        scriptAction.waitUntilElementIsVisible(By.xpath(searchButton), ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(By.xpath(searchButton));

    }
}


