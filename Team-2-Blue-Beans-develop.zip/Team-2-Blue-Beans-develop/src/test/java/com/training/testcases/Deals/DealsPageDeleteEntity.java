package com.training.testcases.Deals;

import com.training.pages.DealsPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class DealsPageDeleteEntity extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger( DealsPageDeleteEntity.class);
    String dealsTitle = CommonUtil.getRandomString("Assign",10);
    @Test(description = "Delete Entity")
    public void deleteEntity() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Deals");
        ExtentTestManager.getTest().pass("Selected Deals Page");

        DealsPage dealsPage = new DealsPage(getDriver());
        HashMap<String, String> objDealsTestData = new HashMap<String, String>();
        dealsPage.selectEntity("Deals");
        objDealsTestData.put("title",dealsTitle);
        dealsPage.createDeal(objDealsTestData);
        Thread.sleep(2000);
        dealsPage.selectEntity("Deals");
        dealsPage.filter("Title","Equals",dealsTitle);
        dealsPage.selectEntity("Deals");
        dealsPage.deleteEntity(dealsTitle, "DELETE");
        logger.info("deal is deleted",dealsTitle);
         Thread.sleep(1000);
        dealsPage.verifyRecordNotDisplayed(dealsTitle);

    }

}
