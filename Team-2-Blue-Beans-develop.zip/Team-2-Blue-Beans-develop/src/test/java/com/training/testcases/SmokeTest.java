package com.training.testcases;

import com.training.pages.*;
import com.training.reporting.ExtentTestManager;
import com.training.utils.CommonUtil;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import java.util.Map;

public class SmokeTest extends BaseTest {

//    private static final String TESTCASENAME = "TC01";
//
//    Map<String, Map<String, String>> sampleTestData;

    @Test(description = "Login to application")
    public void sampleTest() throws Exception {

        //Map<String, String> testDetails = xlsFile.getExcelRowValuesIntoMapBasedOnKey("sampleSheet", TESTCASENAME);

        //Login to Application
        LoginPage loginPage = new LoginPage(getDriver());
        BasePage basePage = new BasePage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");

        CompanyPage companyPage = new CompanyPage(getDriver());
        companyPage.selectEntity(BasePage.EntityPanel.Companies.toString());
        companyPage.performTableOperation("suth","delete");
        companyPage.performOperationOnPopUp("DELETE");
        companyPage.selectEntity(BasePage.EntityPanel.Companies.toString());
        companyPage.verifyRecordDisplayed("qualizeal");


        //casesPage.selectEntity(BasePage.EntityPanel.Cases.toString());
        //casesPage.performTableOperation("xwcYFU","view");
        //casesPage.selectEntity(BasePage.EntityPanel.Cases.toString());
        //casesPage.createCase();
        //casesPage.selectEntity(BasePage.EntityPanel.Cases.toString());
        //casesPage.performTableOperation("xwcYFU","delete");
        //casesPage.deleteConfirmation();

        DealsPage deals = new DealsPage(getDriver());
        deals.selectEntity(BasePage.EntityPanel.Deals.toString());
        //deals.createDeal();
       // deals.errMessage("The field First Name is required.,The field Last Name is required.");
        deals.errMessage("The field Title is required.");
        //deals.searchComboBox("products","chotu");
        deals.selectEntity(BasePage.EntityPanel.Deals.toString());
        //deals.rubbishAndPurge("Deal", "New  Deal", "Purge");
        basePage.selectEntity("Companies");
       // basePage.performOperationOnPopUp("CANCEL");

    }

}

