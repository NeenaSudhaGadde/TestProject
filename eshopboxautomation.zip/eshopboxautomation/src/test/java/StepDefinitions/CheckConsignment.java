package StepDefinitions;

import factory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.OrderPage;
import pages.ShopifyLoginPage;
import utils.ConfigReader;

import java.util.Properties;

public class CheckConsignment {
    WebDriver driver;
    WebDriverWait wait;
    OrderPage orderPage;
    ShopifyLoginPage shopifyLoginPage;
    @Given("Launch Shopify staging url")
    public void launchShopify() throws InterruptedException {
        driver = DriverFactory.getDriver();
        shopifyLoginPage = new ShopifyLoginPage(driver);
        Properties properties = ConfigReader.initializeProperties();
        driver.get(properties.getProperty("shopifyurl"));
        Thread.sleep(5000);
    }
    @And("Login to Shopify")
    public void loginToShopify() {

    }

}
