package com.training.testcases.Deals;

import com.training.pages.DealsPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;

public class DealsPagePurgeSelection extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(DealsPagePurgeSelection.class);
    @Test(description = "purge selection")
    public void purgeOperation() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Deals");
        ExtentTestManager.getTest().pass("Selected Deals Page");

        HashMap<String,String>objTestData= new HashMap<String,String>();
        String dealsTitle = CommonUtil.getRandomString("Assign",10);
        DealsPage dealsPage = new DealsPage(getDriver());
        dealsPage.selectEntity("Deals");
        objTestData.put("title",dealsTitle);
        dealsPage.createDeal(objTestData);
        Thread.sleep(3000);
        dealsPage.selectEntity("Deals");
        dealsPage.filter("Title","Equals",dealsTitle);

        dealsPage.deleteEntity(dealsTitle, "DELETE");
        Thread.sleep(3000);
        dealsPage.rubbishBinEntity("Deal",dealsTitle);
        dealsPage.purgeSelect("Deal",dealsTitle,"OK");
        Thread.sleep(3000);
        dealsPage.verifyRecordNotDisplayed(dealsTitle);
        logger.info("deal is deleted in purge",dealsTitle);
    }
}
