package com.training.testcases.calls;

import com.training.pages.CallsPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;

public class CallsEditDescription extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(CallsEditDescription.class);
    @Test(description = "Edit Calls description")
    public void editDescription() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Calls");
        ExtentTestManager.getTest().pass("Selected Calls Page");

        CallsPage callsPage = new CallsPage(getDriver());
        HashMap<String,String> objCallsData = new HashMap<>();
        objCallsData.put("enterDate","05/Feb/2023");
        objCallsData.put("formatDate","dd/MMM/yyyy");
        objCallsData.put("assignTo","Avi Mummana");
        objCallsData.put("type","CONFERENCE");
        objCallsData.put("contacts","T");
        objCallsData.put("description","Call is done");
        objCallsData.put("duration","15");
        objCallsData.put("flag","Important");
        objCallsData.put("header","Call");
        callsPage.createCall(objCallsData);
        callsPage.takePageScreenShot();
        logger.info("Call is created");

        HashMap<String,String> callsEditTestData = new HashMap<>();
        callsPage.selectEntity("Calls");
        callsEditTestData.put("sExist","Tom Joy");
        callsEditTestData.put("description","Lift the call");
        callsEditTestData.put("header","Call");
        callsPage.editDescription(callsEditTestData);
        callsPage.takePageScreenShot();
        ExtentTestManager.getTest().pass("call Edited");

        callsPage.selectEntity("Calls");
        //verify that current edit record is there or not
        callsPage.filter("Description","Equals","Lift the call");
        callsPage.verifyRecordDisplayed("Tom Joy");
        callsPage.takePageScreenShot();
        callsPage.performTableOperation("Tom Joy","view");
        callsPage.takePageScreenShot();

        callsPage.selectEntity("Calls");
        callsPage.deleteEntity("Tom Joy","DELETE");
        callsPage.verifyRecordNotDisplayed("Tom Joy");
        callsPage.takePageScreenShot();
    }
}
