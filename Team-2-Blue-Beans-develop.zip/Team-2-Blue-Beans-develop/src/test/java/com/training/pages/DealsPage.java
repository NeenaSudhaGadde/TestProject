package com.training.pages;

import com.training.constants.ApplicationConstants;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;


public class DealsPage extends BasePage {
    private static final Logger logger = LoggerFactory.getLogger(DealsPage.class);
    private static By createBtn = By.xpath("//button[@class='ui linkedin button' and text()='Create']");
    private static By DealsTitle = By.xpath("//input[@name='title']");
    String AssignXpath = "//div[@class='ui fluid selection dropdown']/preceding::label[text()='%s']";
    private static By DealsContacts = By.xpath("//div[@name='contacts']/input");
    private static By DealsCompany = By.xpath("//div[@name='company']/input");

    private static By DealsInvalidField = By.xpath("//div[@class='content']/div/following::p");
    private static By buttonSave = By.xpath("//button[@class='ui linkedin button']/i[@class='save icon']");
   // String randomString = RandomStringUtils.randomAlphanumeric(351);
    private static By recordTxt = By.xpath("//table//thead/tr/th[text()='Title']");
   // private static By errorMsgPopUp=By.xpath("//div[@class='content']/p");


    public DealsPage(WebDriver driver) {

        super(driver);
    }

    public DealsPage createDeal(HashMap<String,String> mapDeals) throws InterruptedException {
        clickOnNewDealsButton();
        enterDealsDetails(mapDeals);
      //enterDealsDetails(title, contacts, sValueC, stage, sValueS);
        clickOnSaveButton();
        return this;
    }

    public DealsPage clickOnSaveButton() {
        scriptAction.waitTillClickableAndClick(buttonSave, ApplicationConstants.MEDIUM_TIMEOUT);
        return this;
    }

    public DealsPage clickOnNewDealsButton() {
        scriptAction.waitUntilElementIsVisible(createBtn, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(createBtn);
        checkPageHeader("Create new Deal", "New Deals page is not displayed");
        return this;
    }
    public DealsPage enterDealsDetails(HashMap<String,String> mapDeals) throws InterruptedException {
        scriptAction.waitUntilElementIsVisible(DealsTitle,ApplicationConstants.SHORT_TIMEOUT);
        if(mapDeals.containsKey("title")){
            //Thread.sleep(3000);
            scriptAction.clearAndInputText(DealsTitle,mapDeals.get("title"));
        }
        if(mapDeals.containsKey("contacts")){
            searchNSelectItemFromList("Contacts",mapDeals.get("contacts"));
        }
        if(mapDeals.containsKey("stage")){
            selectItemFromDropdown("Stage",mapDeals.get("stage"));
        }
        return this;
    }

  /*  public DealsPage enterDealsDetails(String title, String contacts, String sValueContact, String stage, String sValueStage) {
        scriptAction.waitUntilElementIsVisible(By.xpath(DealsTitle), ApplicationConstants.MEDIUM_TIMEOUT);
        if (title.length() > 0) {
            scriptAction.inputText(By.xpath(DealsTitle), title);
        }
        if (contacts.length() > 0) {
            searchNSelectItemFromList(contacts, sValueContact);
        }
        if (stage.length() > 0) {
            selectItemFromDropdown(stage, sValueStage);
        }
        return this;
    }*/
  /*  public DealsPage invalidDetails(String title,String contacts,String sValueContact,String stage,String sValueStage){
        clickOnNewDealsButton();
        enterDealsDetails(title,contacts,sValueContact,stage,sValueStage);
        clickOnSaveButton();
        return this;
    }*/
    public void deleteEntity(String sName, String sOperation) throws Exception {
        performTableOperation(sName, "delete");
        checkPopupIsDisplayed("Confirm Deletion");
        performOperationOnPopUp(sOperation);
       // scriptAction.waitUntilElementIsVisible(recordTxt,ApplicationConstants.SHORT_TIMEOUT);

    }
    public void rubbishBinEntity(String pageName,String dName) throws Exception {
        rubbishBin(pageName);

    }
    public void purgeSelect(String pName,String cName,String spop) throws Exception {
        rubbishBinEntity(pName,cName);
        purge(cName);
        purgeSelected("Purge",spop);
    }
    public void editOperation(HashMap<String,String> mapDeals) throws InterruptedException {
        performTableOperation(mapDeals.get("oldtitle"),"edit");
        enterDealsDetails(mapDeals);
        clickOnSaveButton();
        checkPageHeader(mapDeals.get("title"),"it is not displayed");
      //performTableOperation(searchValue,"edit");

    }
    public void saveDeals(String dealsTitle) {
        checkPageHeader(dealsTitle, "Deal is not saved");

    }
}




