package com.training.testcases.Deals;

import com.training.pages.BasePage;
import com.training.pages.DealsPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;

public class DealsPageEditOperation extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(DealsPageEditOperation.class);
    @Test(description = "EditOperation")
    public void deleteEntity() throws Exception {

        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Deals");
        ExtentTestManager.getTest().pass("Selected Deals Page");

        DealsPage dealsPage = new DealsPage(getDriver());
        String dealsTitle = CommonUtil.getRandomString("Deals",15);
       // dealsPage.createDeal("Amazon","Contacts","Tcs","Stage","Negotiate");
        HashMap<String,String> objDealsTestData = new HashMap<String,String>();
        objDealsTestData.put("title",dealsTitle);
        objDealsTestData.put("contacts","wipro ");
        objDealsTestData.put("stage","Research");
        //creating Deal
        dealsPage.createDeal(objDealsTestData);
        logger.info("deal is created",dealsTitle);
        //dealsPage.takePageScreenShot();

        HashMap<String,String> dealsTestData = new HashMap<String,String>();
        String dealsRandTitle = CommonUtil.getRandomString("Data",15);
        Thread.sleep(3000);
        dealsPage.selectEntity("Deals");
        //click on edit old title
         dealsTestData.put("oldtitle",dealsTitle);
        //editing the title
        dealsTestData.put("title",dealsRandTitle);
        //edit the deal
        dealsPage.editOperation(dealsTestData);
        logger.info("deal is edited",dealsRandTitle);
        dealsPage.takePageScreenShot();
        dealsPage.selectEntity("Deals");
        Thread.sleep(1000);
        dealsPage.verifyRecordNotDisplayed(dealsTitle);
        logger.info("record is not display",dealsTitle);
        dealsPage.verifyRecordDisplayed(dealsRandTitle);
        logger.info("record is diplayed",dealsRandTitle);
        dealsPage.deleteEntity(dealsRandTitle,"DELETE");

    }
}