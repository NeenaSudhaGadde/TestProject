package com.training.testcases.Deals;

import com.training.pages.DealsPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

public class DealsPageMandatoryField extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(DealsPageMandatoryField.class);
   // boolean bDelete = false;
    @Test(description = " Create Deal With MandatoryField")
    public void DealsAllField() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Deals");
        ExtentTestManager.getTest().pass("Selected Deals Page");

        HashMap<String, String> objDealsTestData = new HashMap<String, String>();
        String  dealsTitle = CommonUtil.getRandomString("title",10);
        DealsPage dealsPage = new DealsPage(getDriver());
        objDealsTestData.put("title",dealsTitle);
        dealsPage.createDeal(objDealsTestData);
        logger.info("deal mandatoryfield is created",dealsTitle);
        Thread.sleep(2000);
        dealsPage.selectEntity("Deals");
        dealsPage.deleteEntity(dealsTitle,"DELETE");
        Thread.sleep(1000);
        dealsPage.verifyRecordNotDisplayed(dealsTitle);
    }

}
