
package com.training.pages;

import com.training.constants.ApplicationConstants;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import java.util.HashMap;

public class TasksPage extends BasePage {
    private String btnCreateNewCase = "//button[text()='Create']";

    private String titleLocator = "//input[@name = 'title']";

    private String saveButton = "//button[@class = 'ui linkedin button']";

    private String descriptionText = "//textarea[@name = 'description']";

    private String completionTextBox = "//input[@name = 'completion']";

    private String titleXpath = "//th[@class][text()='Title']";

    private String identifierTextBox = "//input[@name= 'identifier']";

    public TasksPage(WebDriver driver) {
        super(driver);
    }

    public TasksPage createTask(HashMap<String, String> mapCreateData, boolean pageHeaderVerification, boolean recordVerification) throws Exception {

        clickOnCreateNewTaskButton();

        checkPageHeader("Create new Task", "page not found");

        refreshPage();

        enterTaskDetails(mapCreateData);

        clickOnSaveButton();

        if (pageHeaderVerification == true) {

            checkPageHeader(mapCreateData.get("title"), "page not found");
        }

        if (recordVerification == true) {

            selectEntity("Tasks");

            verifyRecordDisplayed(mapCreateData.get("title"));

        }

        return this;

    }

    public TasksPage clickOnSaveButton() {

        scriptAction.clickElement(By.xpath(saveButton));

        return this;

    }

    public TasksPage clickOnCreateNewTaskButton() {

        scriptAction.waitUntilElementIsVisible(By.xpath(btnCreateNewCase), ApplicationConstants.SHORT_TIMEOUT);

        scriptAction.clickElement(By.xpath(btnCreateNewCase));

        return this;

    }

    public TasksPage saveTasks(String companiesTitle) {

        checkPageHeader(companiesTitle, "not found");

        return this;

    }

    public TasksPage enterTaskDetails(HashMap<String, String> mapCase) throws InterruptedException {

        scriptAction.waitUntilElementIsVisible(By.xpath(titleLocator), ApplicationConstants.MEDIUM_TIMEOUT, "Page not loaded");

        Thread.sleep(5000);

        if (mapCase.containsKey("title")) scriptAction.clearAndInputText(By.xpath(titleLocator), mapCase.get("title"));

        if (mapCase.containsKey("description"))
            scriptAction.inputText(By.xpath(descriptionText), mapCase.get("description"));

        if (mapCase.containsKey("completion"))
            scriptAction.inputText(By.xpath(completionTextBox), mapCase.get("completion"));

        if (mapCase.containsKey("identifier"))
            scriptAction.inputText(By.xpath(identifierTextBox), mapCase.get("identifier"));

        if (mapCase.containsKey("priority")) selectItemFromDropdown("Priority", mapCase.get("priority"));

        if (mapCase.containsKey("tags")) searchNSelectItemFromList("Tags", mapCase.get("tags"));

        if (mapCase.containsKey("status")) selectItemFromDropdown("Status", mapCase.get("status"));

        return this;

    }

    public TasksPage editRecord(HashMap<String, String> mapEditTasks) throws Exception {

        refreshPage();

        verifyRecordDisplayed(mapEditTasks.get("existingName"));

        performTableOperation(mapEditTasks.get("existingName"), "edit");

        enterTaskDetails(mapEditTasks);

        clickOnSaveButton();

        Thread.sleep(3000);

        checkPageHeader(mapEditTasks.get("title"), "not found");

        return this;

    }

    public TasksPage deleteRecord(HashMap<String, String> mDeleteTask) throws Exception {

        performTableOperation(mDeleteTask.get("title"), "delete");
        performOperationOnPopUp("DELETE");

        //refreshPage();
        Thread.sleep(3000);
        verifyRecordNotDisplayed(mDeleteTask.get("title"));

        return this;

    }

}



