package StepDefinitions;

import java.awt.Frame;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.v110.css.model.CSSStyleSheetHeader;

import factory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.OrderPage;
import pages.ShopifyLoginPage;
import utils.ConfigReader;

public class CreateOrderInShopify {
	WebDriver driver=null;
	OrderPage opage;
	ShopifyLoginPage shloginPage;
	private static String ordernumber;
	
	@Given("Lauch Shopify Staging Url")
	public void lauch_shopify_staging_url() throws InterruptedException {
		driver = DriverFactory.getDriver();
		shloginPage = new ShopifyLoginPage(driver);
		Properties prop = ConfigReader.initializeProperties();
		driver.get(prop.getProperty("shopifystagingurl"));
		Thread.sleep(5000);
	}

	@And("Login To Shopify")
	public void login_to_shopify() throws InterruptedException {
		//driver.findElement(By.xpath("//input[@id='account_email']")).sendKeys("queipoirousegoi-5801@yopmail.com");
		shloginPage.enterEmailId();
		Thread.sleep(5000);
		shloginPage.continueWithEmail();
		Thread.sleep(5000);
		shloginPage.enterPassword();
		Thread.sleep(5000);
		shloginPage.clickOnLogin();
		Thread.sleep(10000);
	}

	@When("Click on Orders Page")
	public void click_on_orders_page() throws InterruptedException {
		opage=new OrderPage(driver);
		opage.orderPageLink();
		Thread.sleep(5000);
		opage.createOrder();
	    Thread.sleep(5000);
	}

	@And("Select Item and Customer")
	public void select_item_and_customer() throws InterruptedException {
		opage.searchProduct();
	    Thread.sleep(5000);
	    opage.itemSelection();
		opage.addItem();
		Thread.sleep(5000);
		opage.searchCustomer();
	    Thread.sleep(5000);
	    opage.customerSelection();
	    Thread.sleep(5000);
	  
	}

	@And("Collect The Payment")
	public void collect_the_payment() throws InterruptedException {
		opage.collectPayment();;
		Thread.sleep(2000);
		opage.markPaid();
		Thread.sleep(5000);
		opage.createbutton();
		Thread.sleep(5000);
		opage.orderPageLink();
		Thread.sleep(5000);
		
	}

	@Then("Caputre the Order Number")
	public void caputre_the_order_number() throws InterruptedException {
		ordernumber=driver.findElement(By.xpath("(//table[@class='Polaris-IndexTable__Table_2qj3m Polaris-IndexTable__Table--sticky_2zprc Polaris-IndexTable__Table--sortable_1ym25']//tr/td)[2]")).getText();
		Thread.sleep(2000);
	    System.out.println(ordernumber);
	}
	
	public static String getCreateOrderInShopify() {
		return ordernumber;
		
	}

}
