package com.training.testcases.company;

import com.training.pages.CompanyPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;

public class DeleteCompanyRecord extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(DeleteCompanyRecord.class);

    @Test(description = "Create company delete fields")
    public void deleteCompanyRecord() throws Exception {

        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Companies");
        ExtentTestManager.getTest().pass("Selected companies Page");

        CompanyPage companyPage = new CompanyPage(getDriver());
        HashMap<String, String> mapData = new HashMap<String, String>();
        String changeName = "epam".concat(CommonUtil.getCurrentTime());
        mapData.put("name", changeName);
        mapData.put("description", "HashMap");
        mapData.put("noOfEmployees", "7");
        mapData.put("industry", "LTDIndustries.PvtLtd..,");
        companyPage.createCompany(mapData);
        logger.info("company is created".concat(changeName));
        Thread.sleep(2000);
        companyPage.selectEntity("Companies");
        companyPage.deleteEntity(changeName,"DELETE");
        logger.info("company record is  deleted".concat(changeName));
        //verify record is not display
        companyPage.verifyRecordNotDisplayed(changeName);
    }
}
