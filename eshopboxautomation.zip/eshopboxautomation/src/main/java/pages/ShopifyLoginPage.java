package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ShopifyLoginPage {
	WebDriver driver=null;
	
	public ShopifyLoginPage(WebDriver driver) {	
		this.driver=driver;	
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//h2[text()='Your store']")
	private WebElement selectStore;
	public void clickOnStore() {
		selectStore.click();;		
	}
	
	@FindBy(xpath="//input[@id='account_email']")
	private WebElement emailId;
	
	@FindBy(xpath="//button[text()='Continue with Email']")
	private WebElement clickNext;
	
	@FindBy(xpath="//input[@id='account_password']")
	private WebElement password;
	
	@FindBy(xpath="//input[@id='account_password']")
	private WebElement passwordTwo;
	
	@FindBy(xpath="//button[text()='Log in']")
	private WebElement login;
	
	@FindBy(xpath = "//span[text()='Qualizeal']")
	private WebElement myStore;
	
	
	
	public void enterEmailId() {
		emailId.sendKeys("queipoirousegoi-5801@yopmail.com");		
	}
	
	public void continueWithEmail() {
		clickNext.click();
	}
	
	public void enterPassword() {
		password.sendKeys("Test@123");		
	}
	
	public void enterPasswordTw0() {
		passwordTwo.sendKeys("Test@123");		
	}
	
	public void clickOnLogin() {
		login.click();		
	}
	
	public void selectStore() {
		myStore.click();		
	}
}
