package com.training.testcases.cases;

import com.training.pages.CasesPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;


public class CasesPageDeleteEntity extends BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(CasesPageDeleteEntity.class);

    @Test(description = "Create cases with All fields")
        public void deleteCasesField() throws Exception {

            LoginPage loginPage = new LoginPage(getDriver());
            loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
            ExtentTestManager.getTest().pass("Logged in to application");
            loginPage.selectEntity("Cases");
            ExtentTestManager.getTest().pass("Selected Cases Page");

            CasesPage casesPage = new CasesPage(getDriver());
            HashMap<String,String> objCasesTestData = new HashMap<>();
            String casesTitle = "cde".concat(CommonUtil.getCurrentTime());
            objCasesTestData.put("title",casesTitle);
            objCasesTestData.put("user","withusers");
            objCasesTestData.put("names","Hajeera  Begum");
            objCasesTestData.put("assignTo","Hajeera  Begum");
            objCasesTestData.put("contact","Abc Xyz");
            objCasesTestData.put("company","Tcs");
            casesPage.createCase(objCasesTestData);
            ExtentTestManager.getTest().pass("created case".concat(casesTitle));

            casesPage.selectEntity("Cases");
            casesPage.deleteCase(casesTitle,"DELETE");
            ExtentTestManager.getTest().pass("case delete".concat(casesTitle));
            casesPage.verifyRecordNotDisplayed(casesTitle);

            //casesPage.createCase("title","withUsers",new String[]{"Hajeera  Begum"},"Hajeera  Begum","hasan","Tcs");
//            casesPage.selectEntity("Cases");
//            casesPage.filter("Title","Equals","title");
//            casesPage.deleteCase("title", "DELETE");
        }
    }
