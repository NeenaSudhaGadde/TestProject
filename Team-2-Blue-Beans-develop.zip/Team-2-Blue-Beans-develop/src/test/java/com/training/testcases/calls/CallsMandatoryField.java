package com.training.testcases.calls;

import com.training.pages.CallsPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;

public class CallsMandatoryField extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(CallsMandatoryField.class);

    @Test(description = "Create calls with Mandatory fields")
    public void callsMandatoryField() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Calls");
        ExtentTestManager.getTest().pass("Selected Calls Page");

        CallsPage callsPage = new CallsPage(getDriver());
        HashMap<String,String> objCallsData = new HashMap<String,String>();
        objCallsData.put("enterDate","09/June/2023");
        objCallsData.put("formatDate","dd/MMM/yyyy");
        objCallsData.put("contacts","u");
        objCallsData.put("header","Call");
        callsPage.createCall(objCallsData);
        logger.info("call is created");
        callsPage.takePageScreenShot();
        ExtentTestManager.getTest().pass("Created call with mandatory");

        callsPage.selectEntity("Calls");
        callsPage.deleteEntity("hajeera Begum","DELETE");
        callsPage.verifyRecordNotDisplayed("hajeera Begum");
        callsPage.takePageScreenShot();
    }
}
