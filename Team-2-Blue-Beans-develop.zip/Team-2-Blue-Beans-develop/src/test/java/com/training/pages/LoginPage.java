package com.training.pages;

import com.training.constants.ApplicationConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;


public class LoginPage  extends BasePage {
    private static Logger logger = LoggerFactory.getLogger(LoginPage.class);


    public LoginPage(WebDriver driver) {
        super(driver);
    }

    private By txtUserEmailID= By.name("email");
    private By txtUserPassword = By.name("password");
    private By btnLogin = By.xpath("//div[text()='Login']");
    private By lnkHome = By.xpath("//i[@class='home icon']");

    public LoginPage loginToApplication(String sUserName, String sPassword) {
        scriptAction.waitUntilElementIsVisible(txtUserEmailID, ApplicationConstants.MEDIUM_TIMEOUT, "Username field is not displayed.");
        //enter username
        scriptAction.inputText(txtUserEmailID, sUserName);
        //enter password
        scriptAction.inputText(txtUserPassword, sPassword);
        //click login
        scriptAction.clickElement(btnLogin);
        //wait until Home page is displayed
        scriptAction.waitUntilElementIsVisible(lnkHome,ApplicationConstants.LONG_TIMEOUT,"Home page is not displayed after login. Check your login details.");
        return this;
    }
}
