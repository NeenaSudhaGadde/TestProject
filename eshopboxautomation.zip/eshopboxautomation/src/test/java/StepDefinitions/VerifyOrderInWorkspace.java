package StepDefinitions;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;

import factory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import utils.ConfigReader;

//Commit Change need to Verify in new branch
public class VerifyOrderInWorkspace{
	WebDriver driver;
	String otp=null;
	String orderid;
	
	
	@Given("Login To Eshopbox Application")
	public void login_to_eshopbox_application() throws InterruptedException {
		Properties prop = ConfigReader.initializeProperties();
		driver = DriverFactory.getDriver();
		driver.get(prop.getProperty("eshopboxstagingurl"));
	    Thread.sleep(3000);
	}

	@And("Enter The UserName")
	public void enter_the_user_name() throws InterruptedException {
		driver.findElement(By.id("1-email")).sendKeys("queipoirousegoi-5801@yopmail.com");
		driver.findElement(By.xpath("//span[text()='Continue']")).click();
		Thread.sleep(3000);
	}

	@And("Open Yopmail in new tab and Caputre the Otp")
	public void open_yopmail_in_new_tab_and_caputre_the_otp() throws InterruptedException {
	driver.switchTo().newWindow(WindowType.TAB);
	driver.get("https://yopmail.com/en/wm");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@id='login']")).sendKeys("queipoirousegoi-5801");
	driver.findElement(By.xpath("//div[@id='refreshbut']")).click();
	List<WebElement> mail = driver.findElements(By.xpath("//button[@onclick='g(this);']"));
	for (WebElement firstMail : mail) {
	firstMail.click();
	Thread.sleep(5000);
	break;
	}
	//Switching to Message frame
	driver.switchTo().frame("ifmail");
	//Getting and adding OTP
	otp = driver.findElement(By.xpath("//b")).getText();
	Thread.sleep(5000);
	}
	

	@And("Switch back to Eshopbox application")
	public void switch_back_to_eshopbox_application() {
		Set<String> windowhandles = driver.getWindowHandles();
		List<String> handles = new ArrayList<String>();
		handles.addAll(windowhandles);
		driver.close();
		driver.switchTo().window(handles.get(0));
	}

	
	@When("Navigate To Eshopbox Application")
	public void navigate_to_eshopbox_application() throws InterruptedException {
		driver.findElement(By.id("1-vcode")).sendKeys(otp);
		//Click on Continue
		driver.findElement(By.id("1-submit")).click();
		Thread.sleep(15000);
	}

	@And("Navigate to Orders page")
	public void navigate_to_orders_page() throws InterruptedException {
	    driver.findElement(By.xpath("//span[normalize-space(text())='Orders']")).click();
	    Thread.sleep(15000);
	}

	@And("Search for the Newly created order")
	public void search_for_the_newly_created_order() throws InterruptedException {		
		Thread.sleep(50000);
		WebElement search = driver.findElement(By.xpath("//input[@name='queyrSearch']"));
		orderid=CreateOrderInShopify.getCreateOrderInShopify();
	    search.sendKeys(orderid);
	    search.sendKeys(Keys.ENTER);
	    Thread.sleep(3000);
	}

	@Then("Verify the newly created order")
	public void verify_the_newly_created_order() {
		String actual = driver.findElement(By.xpath("//span[text()='Cust. order ID ']//following::span/b[@class='order-id']")).getText();
		Assert.assertEquals(actual,orderid); 
	}
}
