package com.training.testcases.cases;

import com.training.pages.CasesPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;

public class CasesPageEditField extends BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(CasesPageEditField.class);
    @Test(description = "Create cases with All fields")
    public void caseEditField() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Cases");
        ExtentTestManager.getTest().pass("Selected Cases Page");

        CasesPage casesPage = new CasesPage(getDriver());
        HashMap<String,String> objCasesData = new HashMap<>();
        String casesTitle = "Naresh".concat(CommonUtil.getCurrentTime());
        objCasesData.put("title",casesTitle);
        objCasesData.put("user","withusers");
        objCasesData.put("names","pavani kopanathi");
        objCasesData.put("assignTo","Hajeera  Begum");
        objCasesData.put("contact","hasan");
        objCasesData.put("company","Tcs");
        objCasesData.put("casename",casesTitle);
        casesPage.createCase(objCasesData);
        casesPage.takePageScreenShot();
        logger.info("Case is created".concat(casesTitle));
        HashMap<String,String> objEditData = new HashMap<>();
        String newTitle = "Jyothi".concat(CommonUtil.getCurrentTime());
        casesPage.selectEntity("Cases");
        objEditData.put("existingcase",casesTitle);
        objEditData.put("title",newTitle);
        casesPage.editCase(objEditData);
        //verify previous record is deleted or not
        casesPage.selectEntity("Cases");
        casesPage.filter("Title","Equals",casesTitle);
        casesPage.verifyRecordNotDisplayed(casesTitle);
        //verify new record is displayed
        casesPage.filter("Title","Equals",newTitle);
        casesPage.verifyRecordDisplayed(newTitle);

        //delete the case
        casesPage.selectEntity("Cases");
        casesPage.deleteCase(newTitle,"DELETE");
        casesPage.verifyRecordNotDisplayed(newTitle);
        casesPage.takePageScreenShot();
    }
}
