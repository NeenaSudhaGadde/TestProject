package com.training.testcases.taskPage;
import com.training.constants.ApplicationConstants;
import com.training.pages.BasePage;
import com.training.pages.LoginPage;
import com.training.pages.TasksPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.testng.annotations.Test;

import java.util.HashMap;

public class CreateNewTask extends BaseTest {
    @Test
    public void createNewTask() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Tasks");
        TasksPage tasksPage = new TasksPage(getDriver());
        HashMap<String, String> mapData = new HashMap<String, String>();
        String title = CommonUtil.getRandomString("Title", 8);
        mapData.put("title", title);
        mapData.put("description", "Qualizeal");
        mapData.put("priority", "High");
        mapData.put("tags", "xyz");
        mapData.put("completion", "100");
        mapData.put("identifier", "surajvootukuri2000@gmail.com");
        mapData.put("status", "Enquiring");
        tasksPage.createTask(mapData, true, true);
        HashMap<String, String> mDeleteData = new HashMap<String, String>();
        mDeleteData.put("title", title);
        tasksPage.deleteRecord(mDeleteData);
    }
}
