package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrderPage {
	
	WebDriver driver=null;
	
	public OrderPage(WebDriver driver){		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//span[text()='Create order']")
	private WebElement orderButton;
	public void createOrder() {
		orderButton.click();
	}
	
	@FindBy(xpath = "(//h2[text()='Products']/following::div//input)[1]")
	private WebElement productSearch;
	public void searchProduct() {
		productSearch.sendKeys(" Levis TShirt");
	}
	
	@FindBy(xpath = "//div[@class='txPIe']/span[text()='Levis TShirt']")
	private WebElement selectItem;
	public void itemSelection() {
		selectItem.click();
	}
	
	@FindBy(xpath = "//span[text()='Add']")
	private WebElement addItemButton;
	public void addItem() {
		addItemButton.click();
	}
	
	@FindBy(xpath = "(//h2[text()='Customer']/following::div//input)[1]")
	private WebElement searchTheCustomer;
	public void searchCustomer() throws InterruptedException {
		searchTheCustomer.click();
		searchTheCustomer.sendKeys("janakiram.vutukuri@qualizeal.com");
		Thread.sleep(5000);
		
	}
	
	@FindBy(xpath = "//span[text()='janakiram.vutukuri@qualizeal.com']")
	private WebElement selectCustomer;
	public void customerSelection() {
		selectCustomer.click();
	}
	
	@FindBy(xpath = "//span[text()='Collect payment']")
	private WebElement collectPaymentButton;
	public void collectPayment() {
		collectPaymentButton.click();
	}
	
	@FindBy(xpath = "//span[text()='Enter credit card']")
	private WebElement creditCardOption;
	public void selectCreditcard() {
		creditCardOption.click();
	}
	
	@FindBy(xpath = "//label[contains(text(), 'Credit Card Number') and not(@aria-hidden)]/following-sibling::input[@id='number']")
	private WebElement cardNumber;
	public void enterCardNumber() throws InterruptedException {
		Thread.sleep(5000);
		driver.switchTo().frame(1);
		
		cardNumber.sendKeys("1");
	}
	
	@FindBy(xpath = "//label[text()='Name on card' and not(@aria-hidden)]/following-sibling::input[@id='name']\"")
	private WebElement nameOnCard;
	public void enterName() {
		nameOnCard.sendKeys("Bogus Gateway");
	}
	
	@FindBy(xpath = "//label[text()='MM / YY' and not(@aria-hidden)]/following-sibling::input[@id='expiry']")
	private WebElement date;
	public void enterDate() {
		date.sendKeys("1027");
	}
	
	@FindBy(xpath = "//label[text()='Security code' and not(@aria-hidden)]/following-sibling::input[@id='verification_value']")
	private WebElement cvv;
	public void enterCVV() {
		cvv.sendKeys("111");
	}
	
	@FindBy(xpath = "//button[@id='submit-payment-button']")
	private WebElement chargeButton;
	public void clickOnChargeButton() {
		chargeButton.click();
	}
	
	@FindBy(xpath = "//span[text()='Mark as paid']")
	private WebElement markAsPaid;
	public void markPaid() {
		markAsPaid.click();
	}
	
	@FindBy(xpath = "//span[text()='Create order']")
	private WebElement createOrderButton;
	public void createbutton() {
		createOrderButton.click();
	}
	
	@FindBy(xpath = "//span[text()='Orders']")
	private WebElement orderLink;
	public void orderPageLink() {
		orderLink.click();
	}
	
}
