package com.training.testcases.taskPage;

import com.training.pages.BasePage;
import com.training.pages.LoginPage;
import com.training.pages.TasksPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.testng.annotations.Test;

import java.util.HashMap;

public class EditAnExistingTask extends BaseTest {
    @Test
    public void editRecord() throws Exception {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Tasks");
        TasksPage tasksPage = new TasksPage(getDriver());
        HashMap<String, String> mapData = new HashMap<String, String>();
        String title = CommonUtil.getRandomString("Title", 10);
        mapData.put("title", title);
        mapData.put("description", "Qualizeal");
        mapData.put("priority", "High");
        mapData.put("tags", "hii");
        mapData.put("status", "Enquiring");
        tasksPage.createTask(mapData, true, true);
        HashMap<String, String> mapEditData = new HashMap<String, String>();
        String title1 = CommonUtil.getRandomString("Selenium", 20);
        mapEditData.put("existingName", title);
        mapEditData.put("title", title1);
        tasksPage.editRecord(mapEditData);
        tasksPage.selectEntity("Tasks");
        tasksPage.refreshPage();
        tasksPage.verifyRecordNotDisplayed(title);
        tasksPage.verifyRecordDisplayed(title1);
        tasksPage.selectEntity("Tasks");
        HashMap<String, String> mapDeleteData = new HashMap<String, String>();
        mapDeleteData.put("title", mapEditData.get("title"));
        tasksPage.deleteRecord(mapDeleteData);
    }
}
