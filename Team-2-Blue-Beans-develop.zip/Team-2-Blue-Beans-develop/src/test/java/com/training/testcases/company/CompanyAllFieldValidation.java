package com.training.testcases.company;

import com.training.pages.*;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;


public class CompanyAllFieldValidation extends BaseTest{
    private static Logger logger = LoggerFactory.getLogger(CompanyAllFieldValidation.class);
        @Test(description = "Create company with All fields")
        public void companyAllField() throws Exception {

            LoginPage loginPage = new LoginPage(getDriver());
            loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
            ExtentTestManager.getTest().pass("Logged in to application");
            loginPage.selectEntity("Companies");
            ExtentTestManager.getTest().pass("Selected Companies Page");

            CompanyPage companyPage = new CompanyPage(getDriver());
            HashMap<String, String> mapData = new HashMap<String, String>();
            String cName = "Wipro".concat(CommonUtil.getCurrentTime());
            mapData.put("name", cName);
            mapData.put("description", "HashMap");
            mapData.put("noOfEmployees", "7");
            mapData.put("industry", "LTDIndustries.PvtLtd..,");
            companyPage.createCompany(mapData);
            logger.info("company is created".concat(cName));
             Thread.sleep(2000);
            companyPage.selectEntity("Companies");
            companyPage.deleteEntity(cName,"DELETE");
            logger.info("company record is  deleted".concat(cName));
            companyPage.verifyRecordNotDisplayed(cName);

        }
    }


