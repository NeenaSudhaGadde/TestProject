package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="classpath:Features",
glue= {"StepDefinitions","hooks"},monochrome = true,dryRun=false,
plugin = {"pretty","json:target/cucumber.json"} , tags= " @demo or ~@smoke or ~@regression")
public class MyRunner {

}
