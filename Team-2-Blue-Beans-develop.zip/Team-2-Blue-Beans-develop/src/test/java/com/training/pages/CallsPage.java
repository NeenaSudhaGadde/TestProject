package com.training.pages;

import com.training.constants.ApplicationConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class CallsPage extends BasePage {
    private static final Logger logger = LoggerFactory.getLogger(CallsPage.class);
    private static By createBtn = By.xpath("//button[@class='ui linkedin button' and text()='Create']");
    private static By callTimeTxt = By.xpath("//label[text()='Call Time']/following-sibling::div//input[@class='calendarField']");
    private static By monthTxt = By.xpath("//div[@class='react-datepicker__current-month']");
    private static By nextNavigationMonth = By.xpath("//button[@aria-label='Next Month']/span[contains(@class,'react-datepicker') and text()='Next Month']");
    private static By previousNavigationMonth = By.xpath("//button[@aria-label='Previous Month']/span[text()='Previous Month']");
    private static By buttonSave = By.xpath("//button[@class='ui linkedin button']/i[@class='save icon']");
    private static By description = By.xpath("//div[@class='ui field']/textarea[@name='description']");
    String dateSelect = "//div[@class='react-datepicker']//div[not(contains(@class,'react-datepicker__day--outside-month'))]/div[text()='%s']";
    private static By duration = By.xpath("//label[text()='Duration']/following::div/input[@name='duration']");
    public CallsPage(WebDriver driver) {
        super(driver);
    }

    public CallsPage createCall(HashMap<String,String> objCallsData) throws Exception {
        clickOnNewCallsButton();
        scriptAction.refreshPage();
        enterCallsDetails(objCallsData);
        clickOnSaveButton();
        checkPageHeader(objCallsData.get("header"),"Calls page is not saved");
        logger.info("call is created");
        return this;
    }

    public CallsPage clickOnSaveButton() {
        scriptAction.waitUntilElementIsVisible(buttonSave, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(buttonSave);
        return this;
    }

    public CallsPage clickOnNewCallsButton() {
        scriptAction.waitUntilElementIsVisible(createBtn, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(createBtn);
        logger.info("call is new create");
        checkPageHeader("Create new Call", "New Calls page is not displayed for creation");
        return this;
    }

    public CallsPage enterCallsDetails(HashMap<String,String> mapCalls) throws Exception {
        scriptAction.waitUntilElementIsVisible(callTimeTxt,ApplicationConstants.MEDIUM_TIMEOUT);
        String enterDate = "";
        if(mapCalls.containsKey("enterDate")) {
            enterDate = mapCalls.get("enterDate");
        }
        if(mapCalls.containsKey("formatDate")) {
            callTimeField(enterDate,mapCalls.get("formatDate"));
        }
        if(mapCalls.containsKey("assignTo")) {
            selectItemFromDropdown("Assigned To",mapCalls.get("assignTo"));
        }
        if(mapCalls.containsKey("type")) {
            selectItemFromDropdown("Type",mapCalls.get("type"));
        }
        if(mapCalls.containsKey("contacts")) {
            searchNSelectItemFromList("Contacts",mapCalls.get("contacts"));
        }
        if(mapCalls.containsKey("description")) {
            scriptAction.clearAndInputText(description,mapCalls.get("description"));
        }
        if(mapCalls.containsKey("duration")) {
            scriptAction.clearAndInputText(duration,mapCalls.get("duration"));
        }
        if(mapCalls.containsKey("flag")) {
            selectItemFromDropdown("Flag",mapCalls.get("flag"));
        }
        return this;
    }

   /* public CallsPage enterCallsDetails(String month, String callsTableDate, String assignDetails, String sType, String contactDetails, String desTxt) {
        if (month.length() > 0) {
            callTimeField(month,callsTableDate);
        }
        if (assignDetails.length() > 0) {
            selectItemFromDropdown("Assigned To", assignDetails);
        }
        if(sType.length()>0) {
            selectItemFromDropdown("Type",sType);
        }
        if (contactDetails.length() > 0) {
            searchNSelectItemFromList("Contacts", contactDetails);
        }
        if(desTxt.length()>0) {
            scriptAction.inputText(description,desTxt);
        }
        return this;
    }*/

    public void callTimeField(String targetDate,String dateFormat) throws Exception {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat targetDateFormat = new SimpleDateFormat(dateFormat);
        Date formattedTargetDate;
        try {
            //give incorrect date it throws exception
            targetDateFormat.setLenient(false);
            formattedTargetDate = targetDateFormat.parse(targetDate);
            calendar.setTime(formattedTargetDate);
            int targetDay = calendar.get(Calendar.DAY_OF_MONTH);
            int targetMonth = calendar.get(Calendar.MONTH);
            int targetYear = calendar.get(Calendar.YEAR);
            //click on CallTime field in calls page
            scriptAction.clickElement(callTimeTxt);
            String actualDate = scriptAction.findElement(monthTxt).getText();
            //calendar format of date in actual date
            calendar.setTime(new SimpleDateFormat("MMM yyyy").parse(actualDate));
            int actualMonth = calendar.get(Calendar.MONTH);
            int actualYear = calendar.get(Calendar.YEAR);
            while (targetMonth < actualMonth || targetYear < actualYear) {
                //click on navigation of previous in calendar
                scriptAction.jsClickElement(previousNavigationMonth);
                logger.info("click on previous navigation in calendar");
                actualDate = scriptAction.findElement(monthTxt).getText();
                calendar.setTime(new SimpleDateFormat("MMM yyyy").parse(actualDate));
                actualMonth = calendar.get(Calendar.MONTH);
                actualYear = calendar.get(Calendar.YEAR);
            }
            while (targetMonth > actualMonth || targetYear > actualYear) {
                //click on navigation of next in calendar
                scriptAction.jsClickElement(nextNavigationMonth);
                logger.info("click on next navigation in calendar");
                actualDate = driver.findElement(monthTxt).getText();
                calendar.setTime(new SimpleDateFormat("MMM yyyy").parse(actualDate));
                actualMonth = calendar.get(Calendar.MONTH);
                actualYear = calendar.get(Calendar.YEAR);
            }
            //click on date
            scriptAction.clickElement(By.xpath(String.format(dateSelect,targetDay)));
            logger.info("click on selected date");
        } catch (ParseException e) {
            throw new Exception("Invalid date is provided, please check input date");
        }
    }

    public CallsPage editDescription(HashMap<String,String> mapCallsEdit) throws Exception {
        performTableOperation(mapCallsEdit.get("sExist"),"edit");
        enterCallsDetails(mapCallsEdit);
        clickOnSaveButton();
        checkPageHeader(mapCallsEdit.get("header"),"page is not saved");
        logger.info("edit the call");
        return this;
    }

    public void deleteEntity(String searchName,String sOperation) {
        performTableOperation(searchName,"delete");
        checkPopupIsDisplayed("Confirm Deletion");
        if(sOperation.equals("CANCEL")) {
            performOperationOnPopUp(sOperation);
            logger.info("Deletion is cancel");
        }else if(sOperation.equals("DELETE")) {
            performOperationOnPopUp(sOperation);
            logger.info("Deletion is success");
        }
    }
    public CallsPage invalidCreateCalls(HashMap<String,String> callsData) throws Exception {
        clickOnNewCallsButton();
        scriptAction.refreshPage();
        enterCallsDetails(callsData);
        clickOnSaveButton();
        logger.error("Enter calls mandatory field");
        return this;
    }
}
