package factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {
	static WebDriver driver;
	public static void intitalizeBrowser(String browserName) {
		//Headless
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless");
		if(browserName.equals("chrome")) {
			if(WebDriverManager.isDockerAvailable()) {
				WebDriverManager manager=WebDriverManager.chromedriver().browserInDocker().browserVersion("beta");
				driver=manager.create();
			}else {
			WebDriverManager.chromedriver().setup();			
			driver=new ChromeDriver(options);
			}
		}else if(browserName.equals("firefox")) {
			driver=new FirefoxDriver();
		}else if(browserName.equals("edge")) {
			driver=new EdgeDriver();
		}else if(browserName.equals("safari")) {
			driver=new SafariDriver();
		}	
		
	}
	public static WebDriver getDriver() {
		
		return driver;
		
	}

}
