package com.training.pages;

import com.training.constants.ApplicationConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class CompanyPage extends BasePage {
    private static final Logger logger = LoggerFactory.getLogger(CompanyPage.class);
    private static final By btnCreateNewCompany = By.xpath("//button[text()='Create']");
    private static final By nameXpath = By.xpath("//div[@class='ui right corner labeled input']//input[@name='name']");
    //String addressTxt = "//input[@name='%s']";
    //String countryXpath = "//div[@class='ui fluid search selection dropdown']//div[@class='divider text']";
    private static final By descriptionXpath = By.xpath("//label[text()='Description']/parent::div/textarea");
    private static final By numberOfEmployeeXpath = By.xpath("//input[@name='num_employees']");
    private static final By industryXpath = By.xpath("//input[@name='industry']");
    private static By btnSave = By.xpath("//button[@class='ui linkedin button']/i[@class='save icon']");
    private static final Logger logger1 = LoggerFactory.getLogger(CompanyPage.class);


    public CompanyPage(WebDriver driver) {
        super(driver);
    }

    public CompanyPage createCompany(HashMap<String, String> mapCompany) throws Exception {
        clickOnNewCompanyButton();
        scriptAction.refreshPage();
        enterCompanyDetails(mapCompany);
        clickOnSaveButton();
        //checkPageHeader("Companies", "Company is not saved");
        return this;
    }

    public CompanyPage clickOnSaveButton() {
        scriptAction.waitUntilElementIsVisible(btnSave, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(btnSave);
        return this;
    }

    public CompanyPage clickOnNewCompanyButton() {
        scriptAction.waitUntilElementIsVisible(btnCreateNewCompany, ApplicationConstants.MEDIUM_TIMEOUT);
        scriptAction.clickElement(btnCreateNewCompany);
        checkPageHeader("Create new Company", "New Company page is not displayed for creation");
        return this;
    }

    public CompanyPage enterCompanyDetails(HashMap<String, String> mapCompany) throws Exception {
        scriptAction.waitUntilElementIsVisible(nameXpath, ApplicationConstants.MEDIUM_TIMEOUT);
        if (mapCompany.containsKey("name"))
            scriptAction.clearAndInputText(nameXpath, mapCompany.get("name"));
        if (mapCompany.containsKey("description"))
            scriptAction.clearAndInputText(descriptionXpath, mapCompany.get("description"));
        if (mapCompany.containsKey("noOfEmployees"))
            scriptAction.clearAndInputText((numberOfEmployeeXpath), mapCompany.get("noOfEmployees"));
        if (mapCompany.containsKey("industry"))
            scriptAction.clearAndInputText(industryXpath, mapCompany.get("industry"));

        return this;
    }
    public CompanyPage editRecord(HashMap<String, String> mapEditCompanyRecord) throws Exception {
        verifyRecordDisplayed((mapEditCompanyRecord.get("existingData")));
        performTableOperation(mapEditCompanyRecord.get("existingData"),"edit");
        scriptAction.refreshPage();
        enterCompanyDetails(mapEditCompanyRecord);
        clickOnSaveButton();
        checkPageHeader(mapEditCompanyRecord.get("name"),"page is not display");
        return this;
    }
    public void deleteEntity(String searchName,String sOperation) {
        performTableOperation(searchName,"delete");
        checkPopupIsDisplayed("Confirm Deletion");
        if(sOperation.equals("CANCEL")) {
            performOperationOnPopUp(sOperation);
            logger.info("Deletion is cancel");
        }else if(sOperation.equals("DELETE")) {
            performOperationOnPopUp(sOperation);
            logger.info("Deletion is success");
        }
    }
}




