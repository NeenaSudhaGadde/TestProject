package com.training.testcases.company;

import com.training.pages.CompanyPage;
import com.training.pages.LoginPage;
import com.training.reporting.ExtentTestManager;
import com.training.testcases.BaseTest;
import com.training.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.HashMap;

public class EditCompanyRecord extends BaseTest {
    private static Logger logger = LoggerFactory.getLogger(EditCompanyRecord.class);
    @Test(description = "Create company edit fields")
    public void editCompanyRecord() throws Exception {

        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.loginToApplication(configurationDetails.getUserName(), configurationDetails.getPassword());
        ExtentTestManager.getTest().pass("Logged in to application");
        loginPage.selectEntity("Companies");
        ExtentTestManager.getTest().pass("Selected companies Page");

        CompanyPage companyPage = new CompanyPage(getDriver());
        HashMap<String, String> mapData = new HashMap<String, String>();
        String companyName = "Quali".concat(CommonUtil.getCurrentTime());
       // String comapanytRand = CommonUtil.get
        //companyPage.createCompany("Quali","Hi-Tech","hyd","tel","500080","India");
        companyPage.selectEntity("Companies");
        mapData.put("name", companyName);
        mapData.put("description", "HashMap");
        mapData.put("noOfEmployees", "7");
        mapData.put("industry", "LTDIndustries.PvtLtd..,");
        companyPage.createCompany(mapData);
        logger.info("created company fields",companyName);

        HashMap<String, String> mapEditData = new HashMap<String, String>();
        String newCompany = "Tcs".concat(CommonUtil.getCurrentTime());
        Thread.sleep(2000);
        companyPage.selectEntity("Companies");
        mapEditData.put("existingData",companyName);
        mapEditData.put("name",newCompany);
        mapEditData.put("description","company is display");
        companyPage.editRecord(mapEditData);
        logger.info("company all fields edited",newCompany);
        companyPage.selectEntity("Companies");
        //verify record previous field is cancel or not
        companyPage.verifyRecordNotDisplayed(companyName);
        //verify current name is there or not
        companyPage.verifyRecordDisplayed(newCompany);
        //Delete the current name record
        companyPage.deleteEntity(newCompany,"DELETE");
        logger.info("company record is  deleted".concat(newCompany));
        companyPage.verifyRecordNotDisplayed(newCompany);


        //companyPage.editCompanyRecord("Tcs","","","","508244","");
       // companyPage.editCompanyRecord("Quail","Mango");

    }
}


